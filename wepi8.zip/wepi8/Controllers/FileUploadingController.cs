﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace wepi8.Controllers
{
    public class FileUploadingController : ApiController
    {
        
        [HttpPost]
        [Route("api/FileUploading/UploadFile")]         
       
       
        public async Task<List<listOfPersons>> UploadFile()
        {
            var ctx = HttpContext.Current;
            var root = ctx.Server.MapPath("~/App_Data");
            var provider = 
                new MultipartFormDataStreamProvider(root);
            var name="";
            var filePath = "";
            string a="";
            List<listOfPersons> output = new List<listOfPersons>();
            try
            {
              await  Request.Content
                    .ReadAsMultipartAsync(provider);

                foreach(var file in provider.FileData)
                {
                     name = file.Headers.ContentDisposition.FileName;

                    name = name.Trim('"');
                    var locaFileName = file.LocalFileName;
                     filePath = Path.Combine(root, name);
                    File.Move(locaFileName, filePath);
                }
                output= FileReader(filePath,name);
                 
                
            }
            catch(Exception e)
            {
               
            }
            return output;
        }

        public List<listOfPersons> FileReader(string filePath, string name)
        {
            StreamReader sr = new StreamReader(filePath);
            string line = "";
            //Int64 count=0;

            List<listOfPersons> ListOfPersons = new List<listOfPersons>();

            //string content = "";
            //string conte = "";

            //while ((line=sr.ReadLine()) != null)
            //{
               
            //    var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            //    var srt = new StreamReader(fs, Encoding.UTF32);
            //    content = sr.ReadLine();
            //     conte = File.ReadAllText(filePath);
            //    //string content = sr.ReadToEnd();               
            //    sr.ReadToEnd();
               
               

                // Read the file and display it line by line.
                System.IO.StreamReader file =
                    new System.IO.StreamReader(filePath);
            int i = 0;
                while ((line = file.ReadLine()) != null)
                {
                    string[] words = line.Split('?');
                string difficulty = words[1];
                i++;
                listOfPersons listofpersons = new listOfPersons();
                listofpersons.questionnumber = i;
                listofpersons.difficultylevel = difficulty;
                    ListOfPersons.Add(listofpersons);
                }

                file.Close();

            //}
            return ListOfPersons;
        }
    }

    public class listOfPersons
    {
        public int questionnumber { get; set; }
        public string difficultylevel { get; set; }            
        
    }
}
